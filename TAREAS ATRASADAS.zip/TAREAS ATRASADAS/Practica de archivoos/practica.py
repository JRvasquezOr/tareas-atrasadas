def calcular_promedios(data):
    
    estudiantes = data.split('|')
    promedios = {}

    for estudiante in estudiantes:
        
        partes = estudiante.split(',')
        nombre = partes[0]
        notas = list(map(int, partes[1:]))  
        promedio = sum(notas) / len(notas)  
        promedios[nombre] = round(promedio)  

    return promedios

def guardar_promedios(promedios, archivo):
    with open(archivo, 'w') as f:
        for nombre, promedio in promedios.items():
            f.write(f"{nombre}={promedio}\n")

if __name__ == "__main__":
    data = "Juan,98,87,89,90|Jose,90,43,20,40|Pedro,70,80,89,90"
    promedios = calcular_promedios(data)
    guardar_promedios(promedios, 'promedios.txt')
    print("Promedios guardados en 'promedios.txt'")
